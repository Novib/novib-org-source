// Reusable product card.
import { Product } from "@/lib/products";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { Plus, ShoppingCart } from "lucide-react";
import { toast } from "sonner";

export function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useStore();
  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl border border-border/60 bg-card shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:border-primary/20">
      {/* Image area with badge */}
      <div className="relative aspect-square overflow-hidden bg-muted">
        <span className="absolute left-3 top-3 z-10 rounded-full bg-primary px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-primary-foreground shadow-sm">
          {product.category}
        </span>
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-110"
        />
        {/* Subtle overlay on hover */}
        <div className="absolute inset-0 bg-black/0 transition-colors duration-300 group-hover:bg-black/5" />
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col gap-2 p-4">
        <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          {product.unit}
        </p>
        <h3 className="text-base font-semibold leading-snug text-foreground">
          {product.name}
        </h3>
        <div className="mt-auto flex items-center justify-between pt-3">
          <span className="text-xl font-extrabold text-primary">
            ${product.price.toFixed(2)}
          </span>
          <Button
            size="sm"
            className="rounded-full bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground shadow-md transition-all duration-200 hover:bg-emerald-600 hover:shadow-lg active:scale-95"
            onClick={() => {
              addToCart(product);
              toast.success(`${product.name} added to cart`);
            }}
          >
            <ShoppingCart className="mr-1.5 h-3.5 w-3.5" />
            Add to Cart
          </Button>
        </div>
      </div>
    </div>
  );
}

