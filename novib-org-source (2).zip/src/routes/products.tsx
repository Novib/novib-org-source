// Product listing with category filter + name search (via search params).
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { z } from "zod";
import { useState, useEffect } from "react";
import { useStore } from "@/lib/store";
import { CATEGORIES } from "@/lib/products";
import { ProductCard } from "@/components/product-card";
import { cn } from "@/lib/utils";
import { Search, X } from "lucide-react";

const searchSchema = z.object({
  category: z.enum(["Fruits", "Vegetables", "Dairy", "Beverages", "Bakery", "Groceries"]).optional(),
  query: z.string().optional(),
});

type ProductSearch = z.infer<typeof searchSchema>;

export const Route = createFileRoute("/products")({
  validateSearch: searchSchema,
  component: ProductsPage,
  head: () => ({
    meta: [
      { title: "Shop Products — Novib Org" },
      { name: "description", content: "Browse our full catalog of fresh groceries." },
    ],
  }),
});

function ProductsPage() {
  const { products } = useStore();
  const { category, query } = Route.useSearch();
  const navigate = useNavigate({ from: "/products" });

  const [searchValue, setSearchValue] = useState(query || "");

  // Sync input with URL query param (e.g. back/forward navigation)
  useEffect(() => {
    setSearchValue(query || "");
  }, [query]);

  // Debounce URL updates
  useEffect(() => {
    const timer = setTimeout(() => {
      navigate({
        search: (prev: ProductSearch) => ({ ...prev, query: searchValue || undefined }),
      });
    }, 300);
    return () => clearTimeout(timer);
  }, [searchValue, navigate]);

  const filtered = products.filter((p) => {
    const matchesCategory = category ? p.category === category : true;
    const matchesQuery = query ? p.name.toLowerCase().includes(query.toLowerCase()) : true;
    return matchesCategory && matchesQuery;
  });

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-bold">All Products</h1>
      <p className="mt-1 text-muted-foreground">Fresh picks across every aisle.</p>

      {/* Search bar */}
      <div className="relative mt-6">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search products..."
          value={searchValue}
          onChange={(e) => setSearchValue(e.target.value)}
          className="h-10 w-full rounded-full border border-input bg-background pl-10 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
        {searchValue && (
          <button
            type="button"
            onClick={() => setSearchValue("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        <Link
          to="/products"
          search={(prev: ProductSearch) => ({ ...prev, category: undefined })}
          className={cn(
            "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
            !category ? "border-primary bg-primary text-primary-foreground" : "hover:bg-accent",
          )}
        >
          All
        </Link>
        {CATEGORIES.map((c) => (
          <Link
            key={c}
            to="/products"
            search={(prev: ProductSearch) => ({ ...prev, category: c })}
            className={cn(
              "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
              category === c ? "border-primary bg-primary text-primary-foreground" : "hover:bg-accent",
            )}
          >
            {c}
          </Link>
        ))}
      </div>

      {filtered.length === 0 ? (
        <p className="mt-12 text-center text-muted-foreground">No products found.</p>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {filtered.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  );
}
