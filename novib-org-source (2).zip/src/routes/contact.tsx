// Contact info + a simple form (no backend yet).
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: "Contact — Novib Org" },
      { name: "description", content: "Visit Novib Org or get in touch — we're here to help." },
    ],
  }),
});

function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: wire up to backend / email service.
    toast.success("Thanks! We'll get back to you soon.");
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-bold">Get in touch</h1>
      <p className="mt-1 text-muted-foreground">Questions, feedback, or special orders — we'd love to hear from you.</p>

      <div className="mt-10 grid gap-8 lg:grid-cols-2">
        <div className="space-y-6">
          <InfoRow icon={MapPin} title="Store location">
            123 Greenway Ave, Garden District<br />Springfield, 90210
          </InfoRow>
          <InfoRow icon={Phone} title="Phone">+1 (555) 012-3456</InfoRow>
          <InfoRow icon={Mail} title="Email">hello@novib.org</InfoRow>
          <InfoRow icon={Clock} title="Hours">
            Mon–Sat: 7am – 9pm<br />Sun: 8am – 6pm
          </InfoRow>
        </div>

        <form onSubmit={handleSubmit} className="rounded-xl border bg-card p-6">
          <h2 className="text-xl font-bold">Send us a message</h2>
          <div className="mt-4 space-y-4">
            <div>
              <Label htmlFor="cname">Name</Label>
              <Input id="cname" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="cemail">Email</Label>
              <Input id="cemail" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="cmsg">Message</Label>
              <Textarea id="cmsg" required rows={4} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
            </div>
            <Button type="submit" className="w-full">Send message</Button>
          </div>
        </form>
      </div>
    </div>
  );
}

function InfoRow({ icon: Icon, title, children }: { icon: React.ComponentType<{ className?: string }>; title: string; children: React.ReactNode }) {
  return (
    <div className="flex gap-4 rounded-xl border bg-card p-5">
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
        <Icon className="h-5 w-5" />
      </span>
      <div>
        <h3 className="font-semibold">{title}</h3>
        <p className="mt-1 text-sm text-muted-foreground">{children}</p>
      </div>
    </div>
  );
}
