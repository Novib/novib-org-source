// Checkout: collect details, simulate order placement.
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/checkout")({
  component: CheckoutPage,
  head: () => ({ meta: [{ title: "Checkout — Novib Org" }] }),
});

function CheckoutPage() {
  const { cart, cartTotal, clearCart } = useStore();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", phone: "", address: "" });
  const [orderId, setOrderId] = useState<string | null>(null);

  // Empty cart? Push them back.
  if (cart.length === 0 && !orderId) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <h1 className="text-2xl font-bold">Nothing to checkout</h1>
        <Button asChild className="mt-6"><Link to="/products">Shop products</Link></Button>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // No payment yet — just simulate an order.
    const id = "NOV-" + Math.random().toString(36).slice(2, 8).toUpperCase();
    setOrderId(id);
    clearCart();
  };

  if (orderId) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <CheckCircle2 className="mx-auto h-16 w-16 text-primary" />
        <h1 className="mt-4 text-3xl font-bold">Order confirmed!</h1>
        <p className="mt-2 text-muted-foreground">Thanks {form.name || "friend"} — your fresh groceries are on the way.</p>
        <p className="mt-4 rounded-lg bg-secondary p-3 font-mono text-sm">Order #{orderId}</p>
        <div className="mt-6 flex justify-center gap-3">
          <Button asChild variant="outline"><Link to="/">Home</Link></Button>
          <Button onClick={() => navigate({ to: "/products" })}>Keep shopping</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-[1fr_360px]">
      <form onSubmit={handleSubmit} className="rounded-xl border bg-card p-6">
        <h1 className="text-2xl font-bold">Delivery details</h1>
        <p className="mt-1 text-sm text-muted-foreground">No payment required — pay on delivery.</p>
        <div className="mt-6 space-y-4">
          <div>
            <Label htmlFor="name">Full name</Label>
            <Input id="name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <Label htmlFor="phone">Phone</Label>
            <Input id="phone" type="tel" required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
          <div>
            <Label htmlFor="address">Delivery address</Label>
            <Textarea id="address" required rows={3} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
          </div>
        </div>
        <Button type="submit" size="lg" className="mt-6 w-full">Place Order</Button>
      </form>

      <aside className="h-fit rounded-xl border bg-card p-6">
        <h2 className="text-lg font-bold">Your order</h2>
        <ul className="mt-4 space-y-2 text-sm">
          {cart.map(({ product, quantity }) => (
            <li key={product.id} className="flex justify-between">
              <span className="text-muted-foreground">{product.name} × {quantity}</span>
              <span>${(product.price * quantity).toFixed(2)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex justify-between border-t pt-4 text-lg font-bold">
          <span>Total</span><span>${cartTotal.toFixed(2)}</span>
        </div>
      </aside>
    </div>
  );
}
