// Homepage: hero + categories + featured products.
import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { CATEGORIES } from "@/lib/products";
import { ProductCard } from "@/components/product-card";
import { Apple, Carrot, Milk, CupSoda, Cookie, Package, Truck, ShieldCheck, Sprout } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Index,
});

const categoryIcons = {
  Fruits: Apple,
  Vegetables: Carrot,
  Dairy: Milk,
  Beverages: CupSoda,
  Bakery: Cookie,
  Groceries: Package,
} as const;

function Index() {
  const { products } = useStore();
  const featured = products.slice(0, 4);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-accent/30">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 md:grid-cols-2 md:py-24">
          <div className="flex flex-col justify-center">
            <span className="mb-4 inline-flex w-fit items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
              <Sprout className="h-3.5 w-3.5" /> Locally sourced & organic
            </span>
            <h1 className="text-4xl font-bold leading-tight tracking-tight text-foreground md:text-6xl">
              Fresh Groceries <span className="text-primary">Delivered</span>
            </h1>
            <p className="mt-4 max-w-md text-lg text-muted-foreground">
              Hand-picked produce, dairy and pantry staples from Novib Org —
              brought to your door, fresh and fast.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link to="/products">Shop Now</Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link to="/contact">Visit Us</Link>
              </Button>
            </div>
            <div className="mt-10 flex flex-wrap gap-6 text-sm text-muted-foreground">
              <span className="flex items-center gap-2"><Truck className="h-4 w-4 text-primary" /> Same-day delivery</span>
              <span className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-primary" /> Freshness guaranteed</span>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1542838132-92c53300491e?w=1000"
              alt="Fresh produce"
              className="h-full max-h-[460px] w-full rounded-2xl object-cover shadow-xl"
            />
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <h2 className="text-3xl font-bold">Shop by category</h2>
            <p className="mt-1 text-muted-foreground">Pick what you need, we'll handle the rest.</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {CATEGORIES.map((c) => {
            const Icon = categoryIcons[c];
            return (
              <Link
                key={c}
                to="/products"
                search={{ category: c }}
                className="group flex flex-col items-center gap-3 rounded-xl border bg-card p-6 transition-all hover:-translate-y-1 hover:border-primary hover:shadow-md"
              >
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                  <Icon className="h-7 w-7" />
                </span>
                <span className="font-semibold">{c}</span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Featured */}
      <section className="mx-auto max-w-6xl px-4 pb-16">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="text-3xl font-bold">Featured products</h2>
          <Link to="/products" className="text-sm font-medium text-primary hover:underline">
            View all →
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {featured.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>
    </div>
  );
}
