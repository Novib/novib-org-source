// Cart page: list items, change quantity, see total.
import { createFileRoute, Link } from "@tanstack/react-router";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";

export const Route = createFileRoute("/cart")({
  component: CartPage,
  head: () => ({ meta: [{ title: "Your Cart — Novib Org" }] }),
});

function CartPage() {
  const { cart, setQuantity, removeFromCart, cartTotal } = useStore();

  if (cart.length === 0) {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center px-4 py-24 text-center">
        <ShoppingBag className="h-14 w-14 text-muted-foreground" />
        <h1 className="mt-4 text-2xl font-bold">Your cart is empty</h1>
        <p className="mt-2 text-muted-foreground">Time to fill it with fresh goodies.</p>
        <Button asChild className="mt-6">
          <Link to="/products">Browse products</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-[1fr_360px]">
      <div>
        <h1 className="mb-6 text-3xl font-bold">Your Cart</h1>
        <ul className="divide-y rounded-xl border bg-card">
          {cart.map(({ product, quantity }) => (
            <li key={product.id} className="flex gap-4 p-4">
              <img src={product.image} alt={product.name} className="h-20 w-20 rounded-lg object-cover" />
              <div className="flex flex-1 flex-col">
                <div className="flex justify-between gap-2">
                  <div>
                    <h3 className="font-semibold">{product.name}</h3>
                    <p className="text-xs text-muted-foreground">{product.category} — {product.unit}</p>
                  </div>
                  <p className="font-bold text-primary">${(product.price * quantity).toFixed(2)}</p>
                </div>
                <div className="mt-auto flex items-center justify-between">
                  <div className="flex items-center gap-1 rounded-full border">
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => setQuantity(product.id, quantity - 1)}>
                      <Minus className="h-3.5 w-3.5" />
                    </Button>
                    <span className="w-8 text-center text-sm font-semibold">{quantity}</span>
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => setQuantity(product.id, quantity + 1)}>
                      <Plus className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => removeFromCart(product.id)}>
                    <Trash2 className="mr-1 h-4 w-4" /> Remove
                  </Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>

      <aside className="h-fit rounded-xl border bg-card p-6">
        <h2 className="text-lg font-bold">Order summary</h2>
        <div className="mt-4 space-y-2 text-sm">
          <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>${cartTotal.toFixed(2)}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Delivery</span><span className="text-primary">Free</span></div>
        </div>
        <div className="mt-4 flex justify-between border-t pt-4 text-lg font-bold">
          <span>Total</span><span>${cartTotal.toFixed(2)}</span>
        </div>
        <Button asChild className="mt-6 w-full" size="lg">
          <Link to="/checkout">Checkout</Link>
        </Button>
      </aside>
    </div>
  );
}
