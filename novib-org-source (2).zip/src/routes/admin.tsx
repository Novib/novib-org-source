// Simple admin page to add/edit/delete products.
// No auth — purely a demo CRUD against local state.
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { CATEGORIES, Category, Product } from "@/lib/products";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Pencil, Trash2, Plus, X } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin")({
  component: AdminPage,
  head: () => ({ meta: [{ title: "Admin — Novib Org" }] }),
});

const empty = { name: "", price: "", image: "", category: "Fruits" as Category, unit: "" };

function AdminPage() {
  const { products, addProduct, updateProduct, deleteProduct } = useStore();
  const [editing, setEditing] = useState<Product | null>(null);
  const [form, setForm] = useState(empty);

  const startEdit = (p: Product) => {
    setEditing(p);
    setForm({ name: p.name, price: String(p.price), image: p.image, category: p.category, unit: p.unit });
  };
  const reset = () => { setEditing(null); setForm(empty); };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = { name: form.name, price: parseFloat(form.price), image: form.image, category: form.category, unit: form.unit };
    if (editing) {
      updateProduct(editing.id, payload);
      toast.success("Product updated");
    } else {
      addProduct(payload);
      toast.success("Product added");
    }
    reset();
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-bold">Admin — Products</h1>
      <p className="mt-1 text-muted-foreground">Add, edit and remove items in your catalog.</p>

      <div className="mt-8 grid gap-8 lg:grid-cols-[360px_1fr]">
        <form onSubmit={handleSubmit} className="h-fit rounded-xl border bg-card p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold">{editing ? "Edit product" : "Add product"}</h2>
            {editing && (
              <Button type="button" variant="ghost" size="icon" onClick={reset}>
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
          <div className="mt-4 space-y-3">
            <div>
              <Label htmlFor="pname">Name</Label>
              <Input id="pname" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="pprice">Price (USD)</Label>
              <Input id="pprice" type="number" step="0.01" min="0" required value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="pimg">Image URL</Label>
              <Input id="pimg" type="url" required value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="punit">Unit</Label>
              <Input id="punit" required placeholder="e.g. per kg, 1 Litre, Loaf" value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="pcat">Category</Label>
              <select
                id="pcat"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value as Category })}
              >
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <Button type="submit" className="w-full">
              <Plus className="mr-1 h-4 w-4" /> {editing ? "Save changes" : "Add product"}
            </Button>
          </div>
        </form>

        <div className="rounded-xl border bg-card">
          <ul className="divide-y">
            {products.map((p) => (
              <li key={p.id} className="flex items-center gap-4 p-3">
                <img src={p.image} alt={p.name} className="h-14 w-14 rounded-lg object-cover" />
                <div className="flex-1 min-w-0">
                  <p className="truncate font-semibold">{p.name}</p>
                  <p className="text-xs text-muted-foreground">{p.category} — {p.unit} • ${p.price.toFixed(2)}</p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => startEdit(p)}><Pencil className="h-4 w-4" /></Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => { deleteProduct(p.id); toast.success("Deleted"); if (editing?.id === p.id) reset(); }}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
