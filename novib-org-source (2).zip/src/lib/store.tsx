// Cart + product store using React context + localStorage.
// Swap out for API calls when you wire a backend.
import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { initialProducts, Product } from "./products";

export interface CartItem {
  product: Product;
  quantity: number;
}

interface StoreContextValue {
  products: Product[];
  addProduct: (p: Omit<Product, "id">) => void;
  updateProduct: (id: string, p: Omit<Product, "id">) => void;
  deleteProduct: (id: string) => void;
  cart: CartItem[];
  addToCart: (p: Product) => void;
  setQuantity: (id: string, q: number) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  cartCount: number;
  cartTotal: number;
}

const StoreContext = createContext<StoreContextValue | null>(null);

const PRODUCTS_KEY = "novib_products";
const CART_KEY = "novib_cart";

export function StoreProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [hydrated, setHydrated] = useState(false);

  // Load from localStorage on mount (client-only).
  useEffect(() => {
    try {
      const p = localStorage.getItem(PRODUCTS_KEY);
      if (p) setProducts(JSON.parse(p));
      const c = localStorage.getItem(CART_KEY);
      if (c) setCart(JSON.parse(c));
    } catch {}
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
  }, [products, hydrated]);

  useEffect(() => {
    if (hydrated) localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart, hydrated]);

  const addProduct: StoreContextValue["addProduct"] = (p) => {
    setProducts((prev) => [...prev, { ...p, id: crypto.randomUUID() }]);
  };
  const updateProduct: StoreContextValue["updateProduct"] = (id, p) => {
    setProducts((prev) => prev.map((x) => (x.id === id ? { ...p, id } : x)));
  };
  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((x) => x.id !== id));
  };

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.product.id === product.id);
      if (existing) {
        return prev.map((i) =>
          i.product.id === product.id ? { ...i, quantity: i.quantity + 1 } : i,
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };
  const setQuantity = (id: string, q: number) => {
    if (q <= 0) {
      setCart((prev) => prev.filter((i) => i.product.id !== id));
      return;
    }
    setCart((prev) => prev.map((i) => (i.product.id === id ? { ...i, quantity: q } : i)));
  };
  const removeFromCart = (id: string) =>
    setCart((prev) => prev.filter((i) => i.product.id !== id));
  const clearCart = () => setCart([]);

  const cartCount = cart.reduce((s, i) => s + i.quantity, 0);
  const cartTotal = cart.reduce((s, i) => s + i.quantity * i.product.price, 0);

  return (
    <StoreContext.Provider
      value={{
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        cart,
        addToCart,
        setQuantity,
        removeFromCart,
        clearCart,
        cartCount,
        cartTotal,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
