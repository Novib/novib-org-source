// Dummy product data. Replace with DB calls later.
export type Category = "Fruits" | "Vegetables" | "Dairy" | "Beverages" | "Bakery" | "Groceries";

export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  category: Category;
  unit: string;
}

export const CATEGORIES: Category[] = ["Fruits", "Vegetables", "Dairy", "Beverages", "Bakery", "Groceries"];

export const initialProducts: Product[] = [
  { id: "1", name: "Fresh Bananas", price: 120, category: "Fruits", unit: "per kg", image: "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400" },
  { id: "2", name: "Tomatoes", price: 80, category: "Vegetables", unit: "per kg", image: "https://images.unsplash.com/photo-1592924357228-91a4daa9962b?w=400" },
  { id: "3", name: "Fresh Milk", price: 150, category: "Dairy", unit: "1 Litre", image: "https://images.unsplash.com/photo-1550583724-b2690b85b8a7?w=400" },
  { id: "4", name: "Brown Bread", price: 90, category: "Bakery", unit: "Loaf", image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400" },
  { id: "5", name: "Cooking Oil", price: 350, category: "Groceries", unit: "1 Litre", image: "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400" },
  { id: "6", name: "Apples", price: 200, category: "Fruits", unit: "per kg", image: "https://images.unsplash.com/photo-1568702846914-2b5b1dc39920?w=400" },
  { id: "7", name: "Eggs", price: 280, category: "Dairy", unit: "Tray 30 pcs", image: "https://images.unsplash.com/photo-1506976785307-8732e854ad03?w=400" },
  { id: "8", name: "Rice", price: 180, category: "Groceries", unit: "2 kg", image: "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400" },
  { id: "9", name: "Soda 500ml", price: 60, category: "Beverages", unit: "Bottle", image: "https://images.unsplash.com/photo-1554865874-33abcc7fdb37?w=400" },
  { id: "10", name: "Onions", price: 70, category: "Vegetables", unit: "per kg", image: "https://images.unsplash.com/photo-1620751370758-91d0f54ca5ac?w=400" },
];
